<?php include 'sjednica.php';

    
    $tezina=$_POST['tezina'];
    $pozadinski=$_POST['pozadinski'];
    $glasnoca=$_POST['glasnoca'];
    $nacinR=$_POST['nacinRjesavanja'];
    $sifraKorisnik=$_POST['sifraKorisnik'];
        
    $popisPitanja=array();

       
?>
<html>
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="Content-Type" content="text/html" />
        <title>TESTIRANJE SLUŠNOG UREĐAJA</title>
        <link rel="stylesheet" href="dizajn.css" />
    </head>
    <body>
        <h1><center>TEST<center></h1>
        <br>
        <h2>Odabrane opcije:</h2>
        <p>
        <?php
        $sql="SELECT * FROM tezina WHERE sifraTezina=$tezina";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
             echo "Težina: ".$row[opisTezina];
        }}
            else{
                echo "Error".sql.$conn->error;
            } ?>
        
        </p> 
        <p>
        <?php    
        if ($pozadinski!=0){
        $sql2="SELECT * FROM zvukP WHERE sifraZvuk=$pozadinski";
        $result = mysqli_query($conn, $sql2);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
             echo "Pozadinski zvuk: ".$row[nazivZvuk];
                $pozadina=$row['audioZvuk'];
        }}
            else{
                echo "Error".sql2.$conn->error;
            }}
        
        else {
            echo "Pozadinski zvuk: nema";
        }?>
        
        </p>  
        
        <p>
        <?php
        echo "Glasnoća pozadinskog zvuka: ".$glasnoca*10; ?>
            
        </p>    
        
        <p>
        <?php
        $sql="SELECT * FROM nacin_rjesavanja WHERE sifraNacinRjesavanja=$nacinR";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
             echo "Prikaz pitanja: ".$row[opisNacinRjesavanja];
        }}
            else{
                echo "Error".sql.$conn->error;
            }?>
        </p>
        
        <p>    
        <?php
        $polje=array();
        $sql5="SELECT * FROM tekst WHERE sifraTezina=$tezina";
        $result = mysqli_query($conn, $sql5);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
            $polje_sifre[]=$row['sifraTekst'];
            $polje[]=$row['AudioTekst'];
        }}
            else{
                echo "Error".sql5.$conn->error;
            }
        $str=array_rand($polje,1);
        $sifra = $polje_sifre[$str];
        $arr = explode('/',$polje[$str]);
        $samo_tekst=$arr[3];
        echo "Slučajno odabran tekst: ".$samo_tekst;
        ?> 
     
        </p>   
        <p>    
        <audio src="<?php echo $polje[$str] ?>.mp3" controls="controls" autoplay="autoplay" volume="1" id="mainAudio"></audio>  </p> 
        <div style="display:none;"><audio id="bgAudio" src="<?php echo $pozadina; ?>.mp3" controls="controls" loop="loop"></audio></div>
        <script type="text/javascript">
        var volume = <?php echo $glasnoca/10;  ?>;
        </script>
            
        
        
            
        <form method="post" action="rezultati.php">
        <div id="pitanja" style="display:none;">
        <br>
        <br>
        <h2>Pitanja:</h2>
        <?php 
            //echo $str;
        $sql="SELECT * FROM pitanja WHERE sifraTekst=$sifra";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                array_push($popisPitanja, $row['sifraPitanje']);
            echo '<div class="pitanje">';
            
                echo "<br/>";
                if($nacinR=='1'||$nacinR=='3'){
                    ?><p><?php
                    echo  '<audio src="'.$row['zvukPitanja'].'.mp3" controls="controls" volume="1" id="mainAudio"></audio>';?>
                    </p>
                    <?php
                }
                if($nacinR=='2'||$nacinR=='3'){?>
                <p><?php echo $row['tekstPitanje'];
                }?>
                </p>        
                <p><?php        
                echo 'Da:<input type="radio" name="pitanje'.$row['sifraPitanje'].'" value="da">';
                echo 'Ne:<input type="radio" name="pitanje'.$row['sifraPitanje'].'" value="ne">';
                //echo "</div>";
                ?>
                </p>
                <?php
        }}
            
            else{
                echo "Error".sql.$conn->error;
            }
          
        ?>
        <?php
        echo '<input type="hidden" name="popisPitanja" value="'.join(',', $popisPitanja).'">';
        echo '<input type="hidden" name="tezina" value="'.$tezina.'">';
        echo '<input type="hidden" name="pozadinski" value="'.$pozadinski.'">';
        echo '<input type="hidden" name="glasnoca" value="'.$glasnoca.'">';
        echo '<input type="hidden" name="nacinR" value="'.$nacinR.'">';
        echo '<input type="hidden" name="sifraKorisnik" value="'.$sifraKorisnik.'">';
        echo '<input type="hidden" name="sifraTekst" value="'.$sifra.'">';
        echo '<input type="submit" name="zavrsni" value="Gotovo">';
        ?>    
            
        </div>
            
          
            
        
        </form>  
     <script src="main.js" type="text/javascript"></script>        
    </body>
</html>

<?php include 'sjednica.php';
?>
<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html">
        <title>TESTIRANJE SLUŠNOG UREĐAJA</title>
        <link rel="stylesheet" href="dizajn.css">
    </head>
    <body>
        <form action="naslovna.php" method="post">
            <fieldset>
                <h3><center>OSOBNI PODACI</center></h3>
                <br>
                <input type="text" name="ime" placeholder="Ime">
                <br>
                <br>
                <input type="text" name="prezime" placeholder="Prezime">
                <br><br>
                <input type="submit" name="prijava" value="Prijava">
            </fieldset>
        </form>
    </body>
</html>

<?php include 'sjednica.php';
    if($_POST['prijava']){
        $ime=$_POST['ime'];
        $prezime=$_POST['prezime'];

        $sql="INSERT into korisnik(ime,prezime) values('$ime','$prezime')";
        $result=mysqli_query($conn, $sql);
        if ($result === TRUE) {
        //echo "New record created successfully";
        } else {
            echo "Error1: " . $sql . "<br>" . $conn->error;
        }
        $sifraKorisnik=mysqli_insert_id($conn);
        //echo "sifraKorisnik: ".$sifraKorisnik;
    } 
    else{
        echo "greška";
    }  
    
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html">
        <title>TESTIRANJE SLUŠNOG UREĐAJA</title>
        <link rel="stylesheet" href="bootstrap.min.css">
        <link rel="stylesheet" href="dizajn.css">
    </head>
    <body>
        <h1><center>GLAVNI IZBORNIK</center></h1>

        <form action="test.php" method="post">
        <h2>TEŽINA</h2>
        <br>
        <p>
        Odaberite željenu težinu zvučnog zapisa:
        <br>
            <?php
        $sql = "SELECT * FROM tezina";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
      // output data of each row
            while($row = mysqli_fetch_assoc($result)) {
               echo "<input class='radio-inline' type='radio' name='tezina' value='$row[sifraTezina]'>$row[opisTezina]";
            }
        }
        else {
            echo "Error".sql.$conn->error;
        }?>
         
       </p>
        <br>
            
            
        <h2>POZADINSKI ZVUK</h2>
        <br><p>
        Odaberite željeni pozadinski zvuk i postotak njegove glasnoće:
        <br>
            
        
         <select name="pozadinski">
        <option value='0'>Bez pozadinskog zvuka</option>
    <?php
        $sql = "SELECT * FROM zvukP";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
      // output data of each row
           while($row = mysqli_fetch_assoc($result)) {
            echo "<option value='$row[sifraZvuk]'>$row[nazivZvuk]</option>";
        }}
            else{
                echo "Error".sql.$conn->error;
            }?> 
            </select>
            
        <br>    
        <select name="glasnoca">
            <option value='1'>10%</option>
            <option value='2'>20%</option>
            <option value='3'>30%</option>
            <option value='4'>40%</option>
             <option value='5'>50%</option>
             <option value='6'>60%</option>
             <option value='7'>70%</option>
             <option value='8'>80%</option>
             <option value='9'>90%</option>
             <option value='10'>100%</option>
        </select></p>
         
        <br>
        <h2>PRIKAZ PITANJA</h2>
        <br><p>
        Odaberite način prikaza pitanja:
        <br>
            <?php
        $sql = "SELECT * FROM nacin_rjesavanja";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
      // output data of each row
           while($row = mysqli_fetch_assoc($result)) {
            echo "<input class='radio-inline' type='radio' name='nacinRjesavanja' value='$row[sifraNacinRjesavanja]'>$row[opisNacinRjesavanja]";
        }}
            else{
                echo "Error".sql.$conn->error;
            }?>   
        </p>
        <br>
        
        <input type="hidden" name="sifraKorisnik" value="<?php echo $sifraKorisnik ?>">
        <input type="submit" name="zapocni" value="Započni">
            
    
        <a href="rezultati.php">Kliknite ovdje za prikaz rezultata</a>

    </form>
    </body>
</html>

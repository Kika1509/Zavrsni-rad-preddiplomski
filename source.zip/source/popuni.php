<?php include 'sjednica.php';

$sifra = $polje_sifre[$str];
$arr = explode('/',$polje[$str]);
$samo_tekst=$arr[3];

$sql="SELECT AudioTekst FROM tekst";
$sqlu = "UPDATE tekst SET nazivTekst = ? WHERE AudioTekst = ?";
if ($stmt = mysqli_prepare($conn, $sql)){
    $result = mysqli_query($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ss", $val1, $val2);
    while($row = mysqli_fetch_assoc($result)) {
        $AudioTekst = $row['AudioTekst'];
        echo $AudioTekst;
        $arr = explode('/',$AudioTekst);
        $nazivTekst=$arr[3];
        echo $nazivTekst;
        $val1 = $nazivTekst;
        $val2 = $AudioTekst;
        mysqli_stmt_execute($stmt);
    }
    mysqli_stmt_close($stmt);    
}
?>
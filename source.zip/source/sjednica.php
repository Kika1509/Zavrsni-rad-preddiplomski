<?php
   session_start();
   include 'baza_veza.php';
   
?>
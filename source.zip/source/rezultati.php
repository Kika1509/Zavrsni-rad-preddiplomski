<?php include 'sjednica.php';
if ($_POST) {
    $tezina=$_POST['tezina'];
    $pozadinski=$_POST['pozadinski'];
    $glasnoca=$_POST['glasnoca'];
    $nacinR=$_POST['nacinR'];
    $sifraKorisnik=$_POST['sifraKorisnik'];
    $sifraTekst=$_POST['sifraTekst'];
    
    $popisPitanja= explode(',', $_POST['popisPitanja']);
}

$sql= "INSERT INTO povijest_rjesavanja ( sifraKorisnik, datumVrijeme, sifraTekst, sifraNacinRjesavanja, sifraZvuk, sifraTezina, glasnoca) VALUES (?, NOW(), ?, ?, ?, ?, ?)";
if ($stmt = mysqli_prepare($conn, $sql)) {
    mysqli_stmt_bind_param($stmt, "iiiiii", $val1, $val2, $val3, $val4, $val5, $val6);
    $val1 = $sifraKorisnik;
    $val2 = $sifraTekst;
    $val3 = $nacinR;
    $val4 = $pozadinski;
    $val5 = $tezina;
    $val6 = $glasnoca;
    mysqli_stmt_execute($stmt);
    $sifraPovijest= mysqli_insert_id($conn);
    mysqli_stmt_close($stmt);
}
else {
    echo "Error1: " . $sql . "<br>" . $conn->error;
}

foreach ($popisPitanja as $sifraPitanje) { 
    $sql="SELECT odgovorPitanje FROM pitanja WHERE sifraPitanje=$sifraPitanje";
    $result = mysqli_query($conn, $sql);
    $tocanOdgovor = mysqli_fetch_object($result);
    if ($tocanOdgovor->odgovorPitanje == $_POST["pitanje".$sifraPitanje]) {
        $tocnost = "Točno";
    }
    else {
        $tocnost = "Netočno";
    }
    mysqli_free_result($result);
    $sql="INSERT INTO tocnost (sifraPovijest, sifraPitanje, odgovorPitanje) VALUES (?, ?, ?)";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "iis", $val1, $val2, $val3);
        $val1 = $sifraPovijest;
        $val2 = $sifraPitanje;
        $val3 = $tocnost;
        mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
    }
    else {
        echo "Error1: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="utf-8">
        <meta http-equiv="Content-Type" content="text/html">
        <title>TESTIRANJE SLUŠNOG UREĐAJA</title>
        <link rel="stylesheet" href="bootstrap.min.css">
        <link rel="stylesheet" href="dizajn.css">
    </head>
    <body>
        <h1><center>REZULTATI</center></h1>
        <br>
        <p>Hvala Vam što ste sudjelovali u istraživanju. Vaše rezultate možete vidjeti ispod.</p>
        <br>
        <p>Za povratak na glavni izbornik kliknite
        <a href="index.php">ovdje</a></p>
        <br>
        <?php
$sql="SELECT b.ime AS Ime, b.prezime AS Prezime, d.opisNacinRjesavanja AS NacinRjesavanja, e.nazivZvuk AS pozadinskiZvuk, f.opisTezina AS tezina, a.glasnoca AS glasno, g.odgovorPitanje AS tocno, a.datumVrijeme AS datumVrijeme, h.nazivTekst AS nazivTeksta, i.tekstPitanje AS tekstPitanje
FROM povijest_rjesavanja a
LEFT JOIN korisnik b ON a.sifraKorisnik = b.sifraKorisnik
LEFT JOIN nacin_rjesavanja d ON a.sifraNacinRjesavanja = d.sifraNacinRjesavanja
LEFT JOIN zvukP e ON a.sifraZvuk = e.sifraZvuk
LEFT JOIN tezina f ON a.sifraTezina = f.sifraTezina
LEFT JOIN tocnost g ON a.sifraPovijest=g.sifraPovijest
LEFT JOIN tekst h ON a.sifraTekst=h.sifraTekst
LEFT JOIN pitanja i ON g.sifraPitanje = i.sifraPitanje 
GROUP BY a.sifraKorisnik, i.sifraPitanje
ORDER BY a.datumVrijeme desc";
$result = mysqli_query($conn, $sql);
echo "<table class='table table-bordered'>";
echo "<tr><th>Ime</th><th>Prezime</th><th>Datum i vrijeme</th><th>Naziv teksta</th><th>Prikaz pitanja</th><th>Pozadinska buka</th><th>Težina</th><th>Glasnoća</th><th>Točnost odgovora</th><th>Pitanje</th>";
$sql2 = "SELECT * 
FROM korisnik 
WHERE korisnik.sifraKorisnik = $sifraKorisnik";
$result2 = mysqli_query($conn, $sql2);
$podaci = mysqli_fetch_object($result2);
$imeKorisnika = $podaci->ime;
$prezimeKorisnika = $podaci->prezime;
        
echo "$imeKorisnika";

while($row = mysqli_fetch_assoc($result)) {
    if ($imeKorisnika == $row['Ime']){
        if ($prezimeKorisnika == $row['Prezime']){
            $imeKorisnik = $row['Ime'];
            $prezimeKorisnik = $row['Prezime'];
            $datumVrijeme = $row['datumVrijeme'];
            $sifraTekst=$row['nazivTeksta'];
            $nacinR=$row['NacinRjesavanja'];
            $pozadinski=$row['pozadinskiZvuk'];
            $tezina=$row['tezina'];
            $glasnoca=$row['glasno'];
            $tocnost=$row['tocno'];
            $pitanje=$row['tekstPitanje'];
            echo "<tr><td>".$imeKorisnik."</td><td>".$prezimeKorisnik."</td><td>".$datumVrijeme."</td><td>".$sifraTekst."</td><td>".$nacinR."</td><td>".$pozadinski."</td><td>".$tezina."</td><td>".$glasnoca."</td><td>".$tocnost."</td><td>".$pitanje."</td></tr>";}}
}
echo "</table>"
?>
    </body>


 



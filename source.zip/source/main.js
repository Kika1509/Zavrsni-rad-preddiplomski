mainAudio = document.getElementById('mainAudio');
bgAudio = document.getElementById('bgAudio');
bgAudio.volume = volume;
mainAudio.addEventListener("ended", function() {
  var pitanja = document.getElementById("pitanja");
  pitanja.style["display"] = "block";
  bgAudio.pause();
});
mainAudio.onpause = function() {
  bgAudio.pause();
};
mainAudio.onplay = function(){
    bgAudio.play();
};

mainAudio.onvolumechange = function () {
    bgAudio.volume = mainAudio.volume * volume;
    bgAudio.muted = mainAudio.muted;
}